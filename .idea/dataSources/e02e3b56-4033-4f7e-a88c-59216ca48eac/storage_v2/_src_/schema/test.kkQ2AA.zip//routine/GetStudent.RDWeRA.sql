create procedure GetStudent()
BEGIN
	SELECT* FROM student;
END;

